"""DroidBot-GPT Framework.

An intelligent Android automation framework with AI-powered decision making.
"""

__version__ = "1.0.0"
__author__ = "DroidNot"
__description__ = "Intelligent Android automation with GPT integration" 